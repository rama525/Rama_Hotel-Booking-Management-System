package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.hotelmanagement.bean.AdminLogin;
import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.bean.HotelManagementLogin;
import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.repository.BookingRepository;
import com.capgemini.hotelmanagement.repository.CustomerRegistrationRepository;
import com.capgemini.hotelmanagement.repository.HotelManagementRepository;
import com.capgemini.hotelmanagement.repository.HotelRepository;
import com.capgemini.hotelmanagement.repository.RoomRepository;

public class DaoImpl implements Dao {
	static List<AdminLogin> adminlist = new ArrayList<AdminLogin>();

	static List<CustomerRegistration> customerlist = new CustomerRegistrationRepository()
			.getCustomerRegistrationRepository();
	static List<HotelManagementLogin> managementList = new HotelManagementRepository().getHotelManagementRepository();
	static List<Hotel> hotelList = new HotelRepository().getHotelRepository();
	static List<Booking> bookList = new BookingRepository().getBookingRepository();
	static List<Room> roomList = new RoomRepository().getRoomRepository();
	int CustomerlistSize = customerlist.size();
	int HotellistSize = hotelList.size();
	int BooklistSize = bookList.size();
	int RoomlistSize = roomList.size();

	public boolean addCustomer(CustomerRegistration customerRegistration) {

		customerlist.add(customerRegistration);
		if (CustomerlistSize == customerlist.size() + 1) {

			return false;
		} else {
			return true;
		}
	}

	public boolean getLoginRequest(String username, String password) {
		int count = 0;
		Iterator<CustomerRegistration> itr = customerlist.iterator();

		while (itr.hasNext()) {

			CustomerRegistration customer1 = itr.next();

			if (username.equals(customer1.getUsername()) && password.equals(customer1.getPassword()))
				count++;

		}
		if (count == 0) {
			return false;
		} else {
			return true;
		}

	}

	public boolean getAdminLoginRequest(String username, String password) {
		int count = 0;

		for (AdminLogin admin1 : adminlist) {
			if (admin1.getUsername().equals(username) && admin1.getPassword().equals(password))
				count++;
		}
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	public boolean getHotelManagementLoginRequest(String username, String password) {
		int count = 0;
		for (HotelManagementLogin managementLogin : managementList) {

			if (managementLogin.getUsername().equals(username) && managementLogin.getPassword().equals(password))
				count++;
		}
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	public List<Hotel> getAllHotels(Hotel hotel) {
		return hotelList;

	}

	public List<Booking> getAllBookingsList(Booking booking) {
		return bookList;
	}

	public boolean getBookingForHotel(String hotelName) {

		for (Booking booking1 : bookList) {
			if (booking1.getHotelName().equals(hotelName)) {

				return false;
			}
		}
		return true;

	}

	public boolean addBooking(Booking booking) {
		bookList.add(booking);
		if (BooklistSize == bookList.size() + 1) {

			return false;
		} else {
			return true;
		}

	}

	public List<CustomerRegistration> getAllCustomers(CustomerRegistration customerRegistration) {
		return customerlist;
	}

	public List<Booking> getBookingDetailsForSpecificHotel(String hotelName) {

		for (Booking booking1 : bookList) {

			if (booking1.getHotelName().equals(hotelName)) {
				List<Booking> searchBooking = new ArrayList<Booking>();
				searchBooking.add(booking1);

			}
		}
		return bookList;

	}

	public boolean addHotel(Hotel hotel) {
		hotelList.add(hotel);
		if (HotellistSize == hotelList.size() + 1) {

			return false;
		} else {
			return true;
		}
	}

	public boolean deleteHotel(String hotelName) {
		
		int count = 0;
		Iterator<Hotel> hotel = hotelList.iterator();
		while (hotel.hasNext()) {
			Hotel str = hotel.next();
			if (str.getHotelName().equals(hotelName)) {
				hotel.remove();
			count++;
		}}
		
			return count == 0 ?false:true;		
	}

	public boolean updateHotel(String hotelName) {

		for (Hotel hotel : hotelList) {
			if (hotel.getHotelName().equals(hotelName)) {

				return true;
			}
		}

		return false;

	}

	public Hotel getHotel(String hotelName) {
		for (Hotel hotel2 : hotelList) {
			if (hotel2.getHotelName().equals(hotelName)) {
				return hotel2;
			}
		}
		return null;
	}

	public boolean addRoom(Room room) {
		roomList.add(room);
		if (RoomlistSize == roomList.size() + 1) {

			return false;
		} else {
			return true;
		}
	}

	public boolean deleteRoom(String roomNumber) {
		Iterator<Room> room = roomList.iterator();
		while (room.hasNext()) {
			Room str = room.next();
			int roomNumber1 = Integer.parseInt(roomNumber);
			if (str.getRoomNumber() == (roomNumber1))
				room.remove();
			return true;
		}
		return false;

	}

	public List<Booking> getBookingListRequest() {
		return bookList;
	}

	public boolean updateRoom(String roomNumber) {
		int count = 0;
		int roomNumber1 = Integer.parseInt(roomNumber);
		for (Room room : roomList) {
			if (room.getRoomNumber() == (roomNumber1)) {

				count++;
			}
		}
		if (count == 1) {

			return false;
		}
		return true;

	}


	@Override
	public boolean updateHotelDetails(String hotelName1, Hotel hotel) {
		int count = 0;
		for(Hotel hotel1 : hotelList) {
			if(hotel1.getHotelName().contentEquals(hotelName1)) {
				hotel1.setHotelName(hotel.getHotelName());
				hotel1.setContactNumber(hotel.getContactNumber());
				hotel1.setHotelAddress(hotel.getHotelAddress());
				hotel1.setNoOfRooms(hotel.getNoOfRooms());
				count++;
			}
		}
		return count == 0?false:true;
	}}