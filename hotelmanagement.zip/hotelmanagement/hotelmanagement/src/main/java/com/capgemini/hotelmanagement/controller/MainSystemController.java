package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;


import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.Service;


public class MainSystemController {
	static final Logger log = Logger.getLogger(MainSystemController.class);

	static Scanner sc = new Scanner(System.in);
	static Service service = Factory.getServiceInstance();

	public static void main(String[] args) {

		do {

			log.info("1. Customer Login");
			log.info("2. Admin Login");
			log.info("3. HotelManagemet Login");
			log.info("4. Customer Registration(new user)");
			log.info("5. Exit");
			String choice1 = sc.next();
			while (!service.choiceValidate(choice1)) {
				log.info(" enter valid choice");
				choice1 = sc.next();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {
			case 1:
				CustomerController.login();
				break;
			case 2:
				AdminController.adminLogin();
				break;

			case 3:
				HotelManagementController.hotelManagementLogin();
				break;
			case 4:
				CustomerController.register();
				break;
			case 5:

				System.exit(0);
				sc.close();
				break;

			}
		} while (true);

	}

}
