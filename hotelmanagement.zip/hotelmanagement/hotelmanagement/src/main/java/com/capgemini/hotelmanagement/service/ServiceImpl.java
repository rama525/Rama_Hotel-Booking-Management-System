package com.capgemini.hotelmanagement.service;

import java.util.List;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.dao.Dao;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class ServiceImpl implements Service {
	InputValidation inputValidation = Factory.getInputValidationInstance();
	Dao dao = Factory.getDaoInstance();

	public boolean nameValidation(String name) {
		return inputValidation.nameValidation(name);
	}

	public boolean userNameValidation(String userName) {
		return inputValidation.usernameValidation(userName);
	}

	public boolean passwordValidation(String password) {
		return inputValidation.passwordValidation(password);
	}

	public boolean emailIdValidation(String emailId) {
		return inputValidation.emailValidation(emailId);
	}

	public boolean mobileNoValidation(String mobileNo) {
		return inputValidation.phnoValidation(mobileNo);
	}

	public boolean ageValidation(String age) {
		return inputValidation.ageValidation(age);
	}

	public boolean addCustomerInfo(CustomerRegistration customerRegistration) {
		return dao.addCustomer(customerRegistration);
	}

	public boolean choiceValidate(String choice) {
		return inputValidation.choiceValidate(choice);
	}

	public boolean getLoginCustomer(String username, String password) {
		return dao.getLoginRequest(username, password);
	}

	public boolean getAdminLogin(String username, String password) {
		return dao.getAdminLoginRequest(username, password);
	}

	public boolean getHotelManagementLogin(String username, String password) {
		return dao.getHotelManagementLoginRequest(username, password);
	}

	public boolean choiceValidateCustomerOperations(String choice) {
		return inputValidation.choiceValidateCustomerOperations(choice);
	}

	public boolean choiceValidateAdminOperations(String choice) {
		return inputValidation.choiceValidateAdminOperation(choice);

	}

	public boolean choiceValidateHotelManagementOperations(String choice) {
		return inputValidation.choiceValidateEmployeeOperations(choice);
	}

	public List<Hotel> listOfHotel(Hotel hotel) {
		return dao.getAllHotels(hotel);
	}

	public List<Booking> bookingsList(Booking booking) {
		return dao.getAllBookingsList(booking);
	}

	public boolean bookingForHotel(String hotelName) {
		return dao.getBookingForHotel(hotelName);
	}

	public boolean hotelNameValidation(String hotelName) {
		return inputValidation.hotelNameValidation(hotelName);
	}

	public boolean bookingDateValidation(String bookingDate) {
		return inputValidation.bookingDateValidation(bookingDate);
	}

	public boolean addressValidation(String address) {
		return inputValidation.hotelAddressValidation(address);
	}

	public boolean roomNumberValidation(String roomNo) {
		return inputValidation.roomNumberValidation(roomNo);
	}

	public boolean addBooking(Booking booking) {
		return dao.addBooking(booking);
	}

	public List<CustomerRegistration> customersList(CustomerRegistration customerRegistration) {
		return dao.getAllCustomers(customerRegistration);
	}

	public List<Booking> bookingForSpecificHotel(String hotelName) {
		return dao.getBookingDetailsForSpecificHotel(hotelName);
	}

	public boolean bookingNameValidation(String hotelName) {
		return inputValidation.bookingNameValidation(hotelName);
	}

	public boolean addHotel(Hotel hotel) {
		return dao.addHotel(hotel);
	}

	public boolean choiceValidateOperateHotelDetails(String choice) {
		return inputValidation.choiceValidateOperateHotelDetails(choice);
	}

	public boolean hotelAddressValidation(String address) {
		return inputValidation.hotelAddressValidation(address);
	}

	public boolean deleteHotel(String hotelName) {
		return dao.deleteHotel(hotelName);
	}

	public boolean numOfRoomsValidation(String choice) {
		return inputValidation.numberOfRoomsValidation(choice);
	}

	public boolean updateHotel(String hotelName) {
		return dao.updateHotel(hotelName);
	}

	public String roomTypeValidation(int choice) {
		return inputValidation.roomTypeValidation(choice);
	}

	public boolean roomPriceValidation(String price) {
		return inputValidation.priceValidation(price);
	}

	public boolean addRoom(Room room) {
		return dao.addRoom(room);
	}

	public boolean deleteRoom(String roomNum) {
		return dao.deleteRoom(roomNum);
	}

	public boolean updateRoom(String roomNum) {
		return dao.updateRoom(roomNum);
	}

	public List<Booking> getBookingList() {
		return dao.getBookingListRequest();
	}

	public boolean dateValidation(String bookingDate) {
		return inputValidation.bookingDateValidation(bookingDate);
	}

	

	@Override
	public boolean updateHotelDetails(String hotelName1, Hotel hotel) {
		// TODO Auto-generated method stub
		return dao.updateHotelDetails(hotelName1,hotel);
	}}