package com.capgemini.hotelmanagement.exceptions;

@SuppressWarnings("serial")
public class RoomNumberNotFoundException extends Exception {
	public RoomNumberNotFoundException() {

	}
}
