package com.capgemini.hotelmanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.factory.Factory;

public class CustomerRegistrationRepository {

	List<CustomerRegistration> customer = new ArrayList<CustomerRegistration>();

	@SuppressWarnings("unused")
	public List<CustomerRegistration> getCustomerRegistrationRepository() {

		CustomerRegistration customer1 = Factory.getCustomerRegistrationInstance();
		customer1.setName("ranganath kuntumalla");
		customer1.setUsername("ranganath12");
		customer1.setPassword("Ranganath#12");
		customer1.setPhno(9666927492l);
		customer1.setMailId("ranganath@gmail.com");
		customer1.setAge(23);

		CustomerRegistration customer2 = Factory.getCustomerRegistrationInstance();
		customer2.setName("ramanath kota");
		customer2.setUsername("ramanath23");
		customer2.setPassword("Ramanath#23");
		customer2.setPhno(9000807962l);
		customer2.setMailId("ramanath@gmail.com");
		customer2.setAge(22);

		CustomerRegistration customer3 = Factory.getCustomerRegistrationInstance();
		customer3.setName("sukanya reddy");
		customer3.setUsername("sukanya55");
		customer3.setPassword("Sukanya$55");
		customer3.setPhno(9856425457l);
		customer3.setMailId("sukanya@gmail.com");
		customer3.setAge(24);

		customer.add(customer1);
		customer.add(customer2);
		customer.add(customer3);
		int size = customer.size();

		return customer;

	}

	public boolean setCustomerMethod(CustomerRegistration cr) {

		customer.add(cr);

		return false;

	}

}
