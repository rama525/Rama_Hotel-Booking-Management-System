package com.capgemini.hotelmanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.factory.Factory;

public class RoomRepository {
	public static List<Room> roomList = new ArrayList<Room>();

	public List<Room> getRoomRepository() {

		Room room = Factory.getRoomInstance();

		room.setRoomNumber(101);
		room.setRoomType("Single");
        room.setRoomPrice(800.00);
        
		Room room1 = Factory.getRoomInstance();

		room1.setRoomNumber(102);
		room1.setRoomType("double");
        room.setRoomPrice(650.00);

		roomList.add(room);
		roomList.add(room1);
		return roomList;
	}

	public boolean setRoomMethod(Room r) {

		roomList.add(r);

		return false;
	}
}
