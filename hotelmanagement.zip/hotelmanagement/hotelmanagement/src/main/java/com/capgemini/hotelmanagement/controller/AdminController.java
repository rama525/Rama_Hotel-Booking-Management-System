package com.capgemini.hotelmanagement.controller;

import java.io.FileInputStream;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.exceptions.HotelNameNotFoundException;
import com.capgemini.hotelmanagement.exceptions.InvalidDateException;
import com.capgemini.hotelmanagement.exceptions.RoomNumberNotFoundException;
import com.capgemini.hotelmanagement.bean.AdminLogin;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.Service;

public class AdminController {
	static Scanner scanner = new Scanner(System.in);
	static final Logger log = Logger.getLogger(CustomerController.class);
	private static final Hotel hotel = null;
	static Service service = Factory.getServiceInstance();
	static List<AdminLogin> adminlist = new ArrayList<AdminLogin>();

	// static List<Booking> bookList=new BookingRepository().getBookingRepository();
	public static boolean adminLogin() {
		Properties properties = new Properties();

		try {
			properties.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		String username = properties.getProperty("adminUsername");

		String password = properties.getProperty("adminPassword");

		int count = 0;
		AdminLogin admin = Factory.getAdminInstance();
		admin.setUsername("admin");
		admin.setPassword("admin");

		adminlist.add(admin);
		for (AdminLogin admin1 : adminlist) {
			if (admin1.getUsername().equals(username) && admin1.getPassword().equals(password)) {
				count++;
			}
		}
		if (count == 0) {
			log.info("Login failed");
			return false;
		} else {
			log.info("Login successfully");
			adminLoginOperations();
			return true;
		}

	}

	public static boolean adminLoginOperations() {
		L: do {
			log.info(" 1. View List of Hotels");
			log.info(" 2. View Bookings of Specific Hotel");
			log.info(" 3. View Booking for Specific Date");
			log.info(" 4. Operate Hotel Details");
			log.info(" 5. Operate Room Details");
			log.info(" 6. Logout\n");

			String choice = scanner.next();
			while (!service.choiceValidateAdminOperations(choice)) {
				log.error("Please enter valid choice");
				choice = scanner.next();
			}

			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				listOfHotels();

				break;

			case 2:
				bookingsForHotel();
				break;

			case 3:
				bookingsForSpecificDate();
				break;

			case 4:
				operateHotelDetails();
				break;
			case 5:
				operateRoomDetails();
				break;
			case 6:

				break L;
			}
		} while (true);

		return false;

	}

	public static void listOfHotels() {

		log.info(service.listOfHotel(hotel));

	}

	public static void bookingsForHotel() {
		log.info("Please select, which hotel booking details you required");
		List<Hotel> hotelList = service.listOfHotel(hotel);
		for (Hotel h : hotelList) {

			log.info(h.getHotelName());

		}
		log.info("Please enter hotel name");
		String hotelName = scanner.next();
		while (!service.hotelNameValidation(hotelName)) {
			log.error("Please enter valid hotel name");
			hotelName = scanner.next();
		}
		int count = 0;
		List<Booking> bookList = service.getBookingList();
		for (Booking booking1 : bookList) {

			if (booking1.getHotelName().equals(hotelName)) {
				count++;
				List<Booking> searchBooking = new ArrayList<Booking>();
				searchBooking.add(booking1);
				log.info(searchBooking);
			}
		}
		try {
			if (count == 0) {
				throw new HotelNameNotFoundException();
			} else {
				log.info("===========================");
			}
		} catch (HotelNameNotFoundException e) {
		}
		log.info("Hotel Name Not Found");

	}

	public static void bookingsForSpecificDate() {
		log.info("Enter from date");
		String date = scanner.next();
		while (!service.dateValidation(date)) {
			log.info("Please enter valid date[yyyy-mm-dd] ");
			date = scanner.next();
		}
		LocalDate bookingDate = LocalDate.parse(date);

		int count = 0;
		List<Booking> bookList = service.getBookingList();
		for (Booking booking : bookList) {
			if (booking.getFromDate().equals(bookingDate)) {
				count++;
				List<Booking> searchBooking = new ArrayList<Booking>();
				searchBooking.add(booking);
				log.info(searchBooking);
			}
		}
		try {

			if (count == 0) {
				throw new InvalidDateException();
			} else {
				log.info("==========================");
			}
		} catch (InvalidDateException e) {
			log.info("no booking on that date..");
		}
	}

	public static boolean operateHotelDetails() {

		L: do {

			log.info("1.Add Hotel ");
			log.info("2.Delete Hotel");
			log.info("3.Update Hotel");
			log.info("4.Exit ");
			String choice = scanner.next();
			while (!service.choiceValidateOperateHotelDetails(choice)) {
				log.error("Please enter valid choice(choice should be 1 to 4)");
				choice = scanner.next();
			}
			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				addHotel();
				break;

			case 2:
				deleteHotel();
				break;

			case 3:
				updateHotel();
				break;

			case 4:

				break L;

			default:
				log.error("Please enter valid input");
				break;
			}

		} while (true);
		return false;

	}

	public static void addHotel() {

		log.info(" Please enter hotel name((without spaces)");
		String hotelName = scanner.next();
		while (!service.hotelNameValidation(hotelName)) {
			log.info("Please enter valid hotel name(Hotel name must contain NameOfHotel )  ");
			hotelName = scanner.next();
		}

		log.info("Please enter hotel address");
		String hotelAddress = scanner.next();
		while (!service.hotelAddressValidation(hotelAddress)) {
			log.info("Please enter valid hotel address (Hotel name must contain City) ");
			hotelAddress = scanner.next();
		}

		log.info("Please enter contact number");
		String contactNumber = scanner.next();
		while (!service.mobileNoValidation(contactNumber)) {
			log.info(
					"Please enter valid contact number(Contact number must 10 digits and start with 6-9 digit only)  ");
			contactNumber = scanner.next();
		}
		long hotelContactNumber = Long.parseLong(contactNumber);

		log.info("Please enter total number of rooms in hotel");
		String noOfRooms = scanner.next();
		while (!service.numOfRoomsValidation(noOfRooms)) {
			log.info("please enter valid number of rooms");
			noOfRooms = scanner.next();
		}
		int numberOfRooms = Integer.parseInt(noOfRooms);
		Hotel hotel = Factory.getHotelInstance();
		hotel.setHotelName(hotelName);
		hotel.setHotelAddress(hotelAddress);
		hotel.setNoOfRooms(numberOfRooms);
		hotel.setContactNumber(hotelContactNumber);

		boolean add = service.addHotel(hotel);
		if (add == true) {
			log.info("New  hotel details are added :\n");

		} else {
			log.info("hotel details are not added:");

		}

	}

	public static void deleteHotel() {
		log.info("Please enter hotel name");
		String hotelName1 = scanner.next();
		while (!service.hotelNameValidation(hotelName1)) {
			log.info("Please enter valid hotel name");
			hotelName1 = scanner.next();
		}
		boolean add = service.deleteHotel(hotelName1);
		
		try {
			if (add == false) {
				throw new HotelNameNotFoundException();
			} else {
				log.info("Data Deleted successfully");
			}
		} catch (HotelNameNotFoundException e) {
			log.info("Hotel Name Not Found");

		}

	}

	public static void updateHotel() {

		log.info("Please enter hotel name");
		String hotelName1 = scanner.next();
		while (!service.hotelNameValidation(hotelName1)) {
			log.info("Please enter valid hotel name");
			hotelName1 = scanner.next();
		}
		try {
		boolean add = service.updateHotel(hotelName1);
		if (add == true) {
			log.info("Request is Done ");
			log.info(" ============= update details ==============");
			Hotel hotel = Factory.getHotelInstance();
			log.info("update hotel  name");
			String hotelName2 = scanner.next();
			while (!service.hotelNameValidation(hotelName2)) {
				log.info("please enter valid name");
				hotelName2 = scanner.nextLine();
			}
			hotel.setHotelName(hotelName2);

			log.info("update hotel address");
			String hotelAdress = scanner.nextLine();
			while (!service.hotelAddressValidation(hotelAdress)) {
				log.info("please enter valid address");
				hotelAdress = scanner.nextLine();
			}

			hotel.setHotelAddress(hotelAdress);

			log.info("update number of rooms(2 digits)");
			String numOfRooms = scanner.nextLine();
			while (!service.numOfRoomsValidation(numOfRooms)) {
				log.info("please enter valid number of rooms");
				numOfRooms = scanner.nextLine();
			}

			int numberOfRooms = Integer.parseInt(numOfRooms);
			hotel.setNoOfRooms(numberOfRooms);

			log.info("update contact number(start with 7,8,9)");
			String phno = scanner.nextLine();
			while (!service.mobileNoValidation(phno)) {
				log.info("please enter valid contact number");
				phno = scanner.nextLine();
			}
			long phno1 = Long.parseLong(phno);
			hotel.setContactNumber(phno1);
if(service.updateHotelDetails(hotelName1,hotel)) {
	log.info("updated successfully");
}else {
	log.info("updated not successfully");
}		
			} else {
				throw new HotelNameNotFoundException();
			}
		} catch (HotelNameNotFoundException e) {
			log.info("Hotel name not found");
		}
	}

	public static boolean operateRoomDetails() {

		L: do {

			log.info("1.Add Room");
			log.info("2.Delete Room");
			log.info("3.Update Room");
			log.info("4.Exit ");
			String choice = scanner.next();
			while (!service.choiceValidateOperateHotelDetails(choice)) {
				log.error("Please enter valid choice(choice should be 1 to 4)");
				choice = scanner.next();
			}
			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				addRoom();
				break;

			case 2:
				deleteRoom();
				break;

			case 3:
				updateRoom();
				break;

			case 4:

				break L;

			default:
				log.error("Please enter valid input");
				break;
			}

		} while (true);
		return false;

	}

	public static void addRoom() {

		Room room = Factory.getRoomInstance();

		log.info("Please enter room number");
		String roomNumber1 = scanner.next();
		while (!service.roomNumberValidation(roomNumber1)) {
			log.info("please enter valid room number ");
			roomNumber1 = scanner.next();
		}
		int roomNumber = Integer.parseInt(roomNumber1);

		log.info("Please enter room price");
		String roomPrice = scanner.next();
		while (!service.roomPriceValidation(roomPrice)) {
			log.info("please enter valid room price");
			roomNumber1 = scanner.next();
		}
		double price = Double.parseDouble(roomPrice);
		log.info("Please enter room type");
		log.info("1.single");
		log.info("2.double");
		String choice1 = scanner.next();
		while (!service.choiceValidateCustomerOperations(choice1)) {
			log.info(" enter valid choice");
			choice1 = scanner.next();
		}
		int choice = Integer.parseInt(choice1);
		String roomType = service.roomTypeValidation(choice);

		room.setRoomNumber(roomNumber);
		room.setRoomType(roomType);
		room.setRoomPrice(price);

		boolean add = service.addRoom(room);
		if (add == true) {
			log.info("New  room details are added :\n");

		} else {
			log.info("room details are not added:");

		}

	}

	public static void deleteRoom() {
		log.info("Please enter room number");
		String roomNumber = scanner.next();
		while (!service.roomNumberValidation(roomNumber)) {
			log.info("Please enter valid room Number");
			roomNumber = scanner.next();
		}

		boolean add = service.deleteRoom(roomNumber);
		if (add == true) {

			log.info("Data deleted successfully");
		}
	}

	public static void updateRoom() {
		log.info("Please enter room number");
		String roomNumber1 = scanner.next();
		while (!service.roomNumberValidation(roomNumber1)) {
			log.info("Please enter valid room Number");
			roomNumber1 = scanner.next();
		}
		boolean add = service.updateRoom(roomNumber1);
		if (add == false) {
			log.info("Request is Done ");
			log.info(" ============= update details ==============");
			Room room = Factory.getRoomInstance();
			log.info("update room number(3 digits)");
			String roomNumber = scanner.next();
			while (!Factory.getInputValidationInstance().roomNumberValidation(roomNumber)) {
				log.info("please enter valid room number ");
				roomNumber = scanner.nextLine();
			}

			int roomNum = Integer.parseInt(roomNumber);

			room.setRoomNumber(roomNum);

			log.info("Please enter room price");
			String roomPrice = scanner.next();
			while (!service.roomPriceValidation(roomPrice)) {
				log.info("please enter valid room price");
				roomNumber1 = scanner.next();
			}
			double price = Double.parseDouble(roomPrice);
			room.setRoomPrice(price);
			log.info("update room type(single/double");

			log.info("1.single");
			log.info("2.double");
			String choice1 = scanner.next();
			while (!Factory.getInputValidationInstance().choiceValidateBookingForSpecificHotel(choice1)) {
				log.info(" enter valid choice");
				choice1 = scanner.next();
			}
			int choice = Integer.parseInt(choice1);

			String roomType = Factory.getInputValidationInstance().roomTypeValidation(choice);

			room.setRoomType(roomType);

		}

		try {
			if (add == true) {
				throw new RoomNumberNotFoundException();

			} else {
				log.info("Room Details Updated Sucessfully");

			}
		} catch (RoomNumberNotFoundException e) {
			log.info("Room Number Not Found");
		}

	}
}
