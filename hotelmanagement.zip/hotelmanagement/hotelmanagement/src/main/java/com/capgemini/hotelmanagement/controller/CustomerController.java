
package com.capgemini.hotelmanagement.controller;

import java.time.LocalDate;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.exceptions.HotelNameNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.Service;

public class CustomerController {
	public CustomerController() {

	}

	static Scanner sc = new Scanner(System.in);
	static final Logger log = Logger.getLogger(CustomerController.class);
	private static final Hotel hotel = null;
	static Service service = Factory.getServiceInstance();

	public static void register() {

		log.info("Enter your name(firstname lastname)");
		String name = sc.nextLine();
		while (!service.nameValidation(name)) {
			log.info("please enter valid name(firstname lastname)");
			name = sc.nextLine();
		}

		log.info("Enter username(start with digits or characters,-,_)");
		String username = sc.nextLine();
		while (!service.userNameValidation(username)) {
			log.info("please enter valid username(start with digits or characters,-,_)");
			username = sc.nextLine();
		}

		log.info(
				"Enter password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
		String password = sc.next();
		while (!service.passwordValidation(password)) {
			log.info(
					"please enter valid password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
			password = sc.next();
		}
		

		log.info("Enter phno(start with 7,8,9)");
		String phone = sc.next();
		while (!service.mobileNoValidation(phone)) {
			log.info("please enter valid phno(start with 7,8,9)");
			phone = sc.next();
		}
		long phno = Long.parseLong(phone);

		log.info("Enter mailId(must contain @ .)");
		String mailid = sc.next();
		while (!service.emailIdValidation(mailid)) {
			log.info("please enter valid mailid(must contain @ .)");
			mailid = sc.next();
		}
		log.info("Enter your age(2 digits)");
		String age1 = sc.next();
		while (!service.ageValidation(age1)) {
			log.info("please enter valid age");
			age1 = sc.next();

		}
		int age = Integer.parseInt(age1);

		CustomerRegistration customerRegistration = Factory.getCustomerRegistrationInstance();
		customerRegistration.setName(name);
		customerRegistration.setUsername(username);
		customerRegistration.setPassword(password);
		customerRegistration.setMailId(mailid);
		customerRegistration.setPhno(phno);
		customerRegistration.setAge(age);
		boolean add = service.addCustomerInfo(customerRegistration);
		if (add == true)
			log.info("Registration successful");
		else
			log.info("Registration failed");

	}

	public static void login() {
		log.info("Enter username(start with digits or characters,-,_)");
		String username = sc.nextLine();
		while (!service.userNameValidation(username)) {
			log.info("please enter valid username(start with digits or characters,-,_)");
			username = sc.nextLine();
		}

		log.info("Enter password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
		String password = sc.next();
		while (!service.passwordValidation(password)) {
			log.info(
					"please enter valid password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
			password = sc.next();
		}

		if (service.getLoginCustomer(username, password) == true) {
			log.info("Login successfull");
			customerLoginOperations();
		} else {
			log.info("Login fail");
		}
	}

	public static boolean customerLoginOperations() {
		P: do {
			log.info("Select options below");
			log.info("1.Hotel Booking");
			log.info("2.Exit");
			String choice = sc.next();
			while (!service.choiceValidateCustomerOperations(choice)) {
				log.info("enter the valid choice [1-2]");
				choice = sc.next();
			}
			int option = Integer.parseInt(choice);
			switch (option) {
			case 1:
				bookingHotel();
				break;
			case 2:
				break P;

			}

		} while (true);
		return false;
	}

	public static void bookingHotel() {
		log.info("Please select, which hotel you want to book");
		List<Hotel> hotelList = service.listOfHotel(hotel);
		for (Hotel h : hotelList) {

			log.info(h.getHotelName());
		}
		log.info("Please enter hotel name");
		String hotelName = sc.next();
		while (!service.hotelNameValidation(hotelName)) {
			log.info("please enter valid hotel name");
			hotelName = sc.next();
		}
		
		
		try {
			int  check = 0;
		
			for (Hotel hotel : hotelList) {
				
			if(hotel.getHotelName().contentEquals(hotelName))
				
				check ++;
			}
			if(check == 0) {
				throw new HotelNameNotFoundException();
			}else {
				
				addBooking();
			}
		}catch (HotelNameNotFoundException e) {
			log.info("Hotel Name Not Found");
		}
	}

	public static void addBooking() {
		log.info("Please enter from date(FORMAT:YYYY-MM-DD)");
		sc.next();
		String fromdate = sc.next();
		while (!service.bookingDateValidation(fromdate)) {
			log.info("Please enter valid date(FORMAT:YYYY-MM-DD)");
			fromdate = sc.next();
		}

		LocalDate fromDate = LocalDate.parse(fromdate);
		while (fromDate.isBefore(LocalDate.now())) {
			log.info("please enter a valid Date");
			fromdate = sc.next();
			while (!service.bookingDateValidation(fromdate)) {
				log.info("Please enter valid date in the format  YYYY-MM-DD");
				fromdate = sc.next();
			}
			fromDate = LocalDate.parse(fromdate);

		}
		log.info("Please enter To date(FORMAT:YYYY-MM-DD)");
		String todate = sc.next();
		while (!service.bookingDateValidation(todate)) {
			log.error("Please enter valid date(FORMAT:YYYY-MM-DD)");
			todate = sc.next();
		}

		LocalDate toDate = LocalDate.parse(todate);
		if (toDate.isBefore(fromDate)) {
			log.info("please enter a valid Date");
			todate = sc.next();
			while (!service.bookingDateValidation(todate)) {
				log.info("Please enter valid date in the format  YYYY-MM-DD");
				todate = sc.next();
			}
			toDate = LocalDate.parse(todate);

		}

		log.info("Please enter your name");
		String name = sc.next();
		while (!service.bookingNameValidation(name)) {
			log.info("please enter valid name");
			name = sc.next();
		}

		log.info("Please enter your address");
		String address = sc.next();
		while (!service.addressValidation(address)) {
			log.error("Please enter valid  address");
			address = sc.next();
		}

		log.info("Please enter email(include @ .)");
		String email = sc.next();
		while (!service.emailIdValidation(email)) {
			log.error("Please enter valid  email(include @ .)");
			email = sc.next();
		}

		log.info("Please enter contact number(start with 7,8,9)");
		String contactNumber = sc.next();
		while (!service.mobileNoValidation(contactNumber)) {
			log.error("Please enter valid contact number(start with 7,8,9)");
			contactNumber = sc.next();
		}

		Long contactNumber1 = Long.parseLong(contactNumber);

		log.info("Please enter room number(must have 3 digits)");
		String roomNum = sc.next();
		while (!service.roomNumberValidation(roomNum)) {
			log.info("please enter valid room number(must have 3 digits)");
			roomNum = sc.next();
		}
		int roomNum1 = Integer.parseInt(roomNum);

		Booking booking = Factory.getBookingInstance();

		booking.setFromDate(fromDate);
		booking.setToDate(toDate);
		booking.setName(name);
		booking.setAddress(address);
		booking.setEmail(email);
		booking.setContactNumber(contactNumber1);
		booking.setRoomNum(roomNum1);
		boolean add = service.addBooking(booking);
		if (add == true) {
			log.info("Booking successfull\n");
			log.info("Booking Details:\n " + booking.toString());
		} else {
			log.info("Booking failed");

		}
	}
	
}






