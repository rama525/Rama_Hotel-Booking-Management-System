package com.capgemini.hotelmanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.factory.Factory;

public class HotelRepository {
	public static List<Hotel> hotelList = new ArrayList<Hotel>();

	public List<Hotel> getHotelRepository() {
		Hotel hotel = Factory.getHotelInstance();

		hotel.setHotelName("Tajkrishna");
		hotel.setHotelAddress("Bangalore, Karnataka");
		hotel.setNoOfRooms(20);
		hotel.setContactNumber(9028802697l);

		Hotel hotel1 = Factory.getHotelInstance();

		hotel1.setHotelName("Vivantha");
		hotel1.setHotelAddress("hyderabad,telangana");
		hotel1.setNoOfRooms(25);
		hotel1.setContactNumber(9976645567l);

		hotelList.add(hotel);
		hotelList.add(hotel1);

		return hotelList;

	}

	public boolean setHotelMethod(Hotel h) {

		hotelList.add(h);

		return false;
	}

}
