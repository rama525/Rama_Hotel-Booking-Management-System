package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.Service;

public class HotelManagementController {

	static final Logger log = Logger.getLogger(HotelManagementController.class);
	private static final Booking booking = null;
	private static final CustomerRegistration customerRegistration = null;
	static Service service = Factory.getServiceInstance();
	static Scanner sc = new Scanner(System.in);

	public static void hotelManagementLogin() {
		log.info("Enter username(start with digits or characters,-,_)");
		String username = sc.nextLine();
		while (!service.userNameValidation(username)) {
			log.info("please enter valid username(start with digits or characters,-,_)");
			username = sc.nextLine();
		}

		log.info(
				"Enter password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
		String password = sc.next();
		while (!service.passwordValidation(password)) {
			log.info(
					"please enter valid password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
			password = sc.next();
		}
		if (service.getHotelManagementLogin(username, password) == true) {
			log.info("Login successfull");
			HotelManagementOperations();
		} else {
			log.info("Login fail");
		}
	}

	public static boolean HotelManagementOperations() {
		P: do {

			log.info("1.View Customer List");
			log.info("2.View Booking List");
			log.info("3.hotel Booking");
			log.info("4.Exit");
			String choice = sc.next();
			while (!service.choiceValidateHotelManagementOperations(choice)) {
				log.error("Please enter valid choice");
				choice = sc.next();
			}

			int choice1 = Integer.parseInt(choice);

			switch (choice1) {

			case 1:
				getAllCustomerDetails();
				break;
			case 2:
				bookingsList();
				break;
			case 3:
				CustomerController.bookingHotel();

				break;
			case 4:
				break P;
			default:
				log.info("Enter Valid choice");
				break;
			}

		} while (true);
		return false;

	}

	public static void bookingsList() {
		log.info(service.bookingsList(booking));
	}

	public static void getAllCustomerDetails() {
		log.info(service.customersList(customerRegistration));
	}

}
