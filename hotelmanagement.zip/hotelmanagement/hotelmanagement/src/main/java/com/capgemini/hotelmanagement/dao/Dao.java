package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.bean.Room;

public interface Dao {

	boolean addCustomer(CustomerRegistration customerRegistration);

	public boolean getLoginRequest(String username, String password);

	public boolean getAdminLoginRequest(String username, String password);

	public boolean getHotelManagementLoginRequest(String username, String password);

	public List<Hotel> getAllHotels(Hotel hotel);

	public List<Booking> getAllBookingsList(Booking booking);

	public boolean getBookingForHotel(String hotelName);

	public boolean addBooking(Booking booking);

	public List<CustomerRegistration> getAllCustomers(CustomerRegistration customerRegistration);

	public List<Booking> getBookingDetailsForSpecificHotel(String hotelName);

	public boolean addHotel(Hotel hotel);

	public boolean deleteHotel(String hotelName);

	public boolean updateHotel(String hotelName);

	public Hotel getHotel(String hotelName);

	public boolean addRoom(Room room);

	public boolean deleteRoom(String roomNumber);

	public boolean updateRoom(String roomNumber);

	public List<Booking> getBookingListRequest();

	boolean updateHotelDetails(String hotelName1, Hotel hotel);
}
