package com.capgemini.hotelmanagement.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.factory.Factory;

public class BookingRepository {
	public static List<Booking> bookList = new ArrayList<Booking>();

	public List<Booking> getBookingRepository() {

		Booking booking = Factory.getBookingInstance();

		booking.setFromDate(LocalDate.of(2020, 01, 15));
		booking.setToDate(LocalDate.of(2020, 01, 16));
		booking.setName("rama");
		booking.setHotelName("Takrishna Hotel");
		booking.setAddress("Bangalore");
		booking.setEmail("rama525@gmail.com");
		booking.setContactNumber(9000807962l);
		booking.setRoomNum(111);

		Booking booking2 = Factory.getBookingInstance();

		booking2.setFromDate(LocalDate.of(2020, 05, 25));
		booking2.setToDate(LocalDate.of(2020, 05, 26));
		booking2.setName("geetha");
		booking2.setHotelName("Vivantha Hotel");
		booking2.setAddress("Hyderabad");
		booking2.setEmail("geetha123@gmail.com");
		booking2.setContactNumber(7674081102l);
		booking2.setRoomNum(112);

		Booking booking3 = Factory.getBookingInstance();

		booking3.setFromDate(LocalDate.of(2020, 05, 01));
		booking3.setToDate(LocalDate.of(2020, 05, 02));
		booking3.setName("lucky");
		booking3.setHotelName("Tajkrishna Hotel");
		booking3.setAddress("Banglore");
		booking3.setEmail("lucky@gmail.com");
		booking3.setContactNumber(9666927492l);
		booking3.setRoomNum(113);

		bookList.add(booking);
		bookList.add(booking2);
		bookList.add(booking3);
		return bookList;
	}

	public boolean setBookingMethod(Booking booking) {
		bookList.add(booking);
		return false;
	}
}
