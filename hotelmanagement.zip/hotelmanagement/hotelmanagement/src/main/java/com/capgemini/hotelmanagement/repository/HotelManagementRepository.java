package com.capgemini.hotelmanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.bean.HotelManagementLogin;

public class HotelManagementRepository {
	List<HotelManagementLogin> managementList = new ArrayList<HotelManagementLogin>();

	public List<HotelManagementLogin> getHotelManagementRepository() {
		HotelManagementLogin hotelManagementLogin = Factory.getHotelManagementLoginInstance();
		hotelManagementLogin.setUsername("smiley111");
		hotelManagementLogin.setPassword("Smiley@111");
		managementList.add(hotelManagementLogin);
		HotelManagementLogin hotelManagementLogin1 = Factory.getHotelManagementLoginInstance();
		hotelManagementLogin1.setUsername("sweety222");
		hotelManagementLogin1.setPassword("Sweety@222");
		managementList.add(hotelManagementLogin1);
		return managementList;
	}

	public boolean setEmployeeMethod(HotelManagementLogin h) {

		managementList.add(h);

		return false;

	}

}
