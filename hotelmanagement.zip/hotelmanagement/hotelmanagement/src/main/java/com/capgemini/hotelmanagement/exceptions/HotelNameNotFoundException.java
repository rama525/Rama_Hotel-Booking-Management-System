package com.capgemini.hotelmanagement.exceptions;

@SuppressWarnings("serial")
public class HotelNameNotFoundException extends Exception {

	public HotelNameNotFoundException() {

	}
}
