package com.capgemini.hotelmanagement.factory;

import com.capgemini.hotelmanagement.bean.HotelManagementLogin;
import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.controller.AdminController;
import com.capgemini.hotelmanagement.controller.CustomerController;
import com.capgemini.hotelmanagement.controller.HotelManagementController;
import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.AdminLogin;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.dao.Dao;
import com.capgemini.hotelmanagement.dao.DaoImpl;
import com.capgemini.hotelmanagement.service.Service;
import com.capgemini.hotelmanagement.service.ServiceImpl;
import com.capgemini.hotelmanagement.validation.InputValidation;
import com.capgemini.hotelmanagement.validation.InputValidationImpl;

public class Factory {
	private Factory() {

	}

	public static InputValidation getInputValidationInstance() {

		return new InputValidationImpl();
	}

	public static Service getServiceInstance() {
		Service service = new ServiceImpl();
		return service;

	}

	public static CustomerRegistration getCustomerRegistrationInstance() {
		CustomerRegistration customerRegistration = new CustomerRegistration();
		return customerRegistration;
	}

	public static Dao getDaoInstance() {
		Dao dao = new DaoImpl();
		return dao;
	}

	public static AdminLogin getAdminInstance() {
		return new AdminLogin();
	}

	public static HotelManagementLogin getHotelManagementLoginInstance() {
		return new HotelManagementLogin();
	}

	public static Booking getBookingInstance() {
		return new Booking();
	}

	public static Hotel getHotelInstance() {
		return new Hotel();
	}

	public static Room getRoomInstance() {
		return new Room();
	}

	public static AdminController getAdminControllerInstance() {
		return new AdminController();
	}

	public static CustomerController getCustomerControllerInstance() {
		return new CustomerController();
	}

	public static HotelManagementController getHotelManagementControllerInstance() {
		return new HotelManagementController();
	}
}
