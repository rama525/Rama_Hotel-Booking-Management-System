package com.capgemini.hotelmanagement.exceptions;

@SuppressWarnings("serial")
public class InvalidDateException extends Exception {
	public InvalidDateException() {

	}
}
