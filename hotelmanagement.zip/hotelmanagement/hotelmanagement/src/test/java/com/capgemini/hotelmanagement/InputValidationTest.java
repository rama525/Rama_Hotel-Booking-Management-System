package com.capgemini.hotelmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class InputValidationTest {
	@Test
	@DisplayName("CustomerName")
	void testCustomerName() {
		InputValidation customerNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerNameValidation.nameValidation("ramanath kota"));
	}

	@Test
	@DisplayName("email")
	void testMailId() {
		InputValidation emailValidation = Factory.getInputValidationInstance();
		assertEquals(true, emailValidation.emailValidation("ramanath@gmail.com"));
	}

	@Test
	@DisplayName("contact number")
	void testPhno() {
		InputValidation phnoValidation = Factory.getInputValidationInstance();
		assertEquals(true, phnoValidation.hotelContactNumberValidation("9000807962"));
	}

	@Test
	@DisplayName("username")
	void testUserName() {
		InputValidation usernameValidation = Factory.getInputValidationInstance();
		assertEquals(true, usernameValidation.usernameValidation("ramanath23"));
	}

	@Test
	@DisplayName("password")
	void testPassword() {
		InputValidation passwordValidation = Factory.getInputValidationInstance();
		assertEquals(true, passwordValidation.passwordValidation("Ramanath#23"));
	}

	@Test
	@DisplayName("age")
	void testAge() {
		InputValidation ageValidation = Factory.getInputValidationInstance();
		assertEquals(true, ageValidation.ageValidation("22"));
	}

	@Test
	@DisplayName("coice")
	void testChoice() {
		InputValidation choiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, choiceValidation.choiceValidate("2"));
	}

	@Test
	@DisplayName("choiceAdmin")
	void testAdminChoice() {
		InputValidation adminchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, adminchoiceValidation.choiceValidateAdminOperation("3"));
	}

	@Test
	@DisplayName("specificHotelcoice")
	void testSpecificHotelChoice() {
		InputValidation specifichotelchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, specifichotelchoiceValidation.choiceValidateBookingForSpecificHotel("2"));
	}

	@Test
	@DisplayName("booking date")
	void testBookingDate() {
		InputValidation bookingDateValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingDateValidation.bookingDateValidation("2020-05-01"));
	}

	@Test
	@DisplayName("hotel name")
	void testHotelName() {
		InputValidation hotelNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelNameValidation.hotelNameValidation("Tajkrishna"));
	}

	@Test
	@DisplayName("hotel adress")
	void testHotelAdress() {
		InputValidation hotelAdressValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelAdressValidation.hotelAddressValidation("Bangalore"));
	}

	@Test
	@DisplayName("hotel contact number")
	void testHotelContactNumber() {
		InputValidation hotelContactNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelContactNumberValidation.hotelContactNumberValidation("9028802697"));
	}

	@Test
	@DisplayName("hotel details choice")
	void testHotelDetailsChoice() {
		InputValidation hotelDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelDeatilsChoiceValidation.choiceValidateOperateHotelDetails("2"));
	}

	@Test
	@DisplayName("Room details choice")
	void testRoomDetailsChoice() {
		InputValidation roomDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomDeatilsChoiceValidation.choiceValidateOperateRoomDetails("2"));
	}

	@Test
	@DisplayName("Customer Operations")
	void testCustomerOperations() {
		InputValidation customerOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerOperationsValidation.choiceValidateCustomerOperations("2"));
	}

	@Test
	@DisplayName("Employee Operations")
	void testEmployeeOperations() {
		InputValidation employeeOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, employeeOperationsValidation.choiceValidateEmployeeOperations("2"));
	}

	@Test
	@DisplayName("room number")
	void testRoomNumber() {
		InputValidation roomNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomNumberValidation.roomNumberValidation("111"));
	}

	@Test
	@DisplayName("room type")
	void testRoomType() {
		InputValidation roomTypeValidation = Factory.getInputValidationInstance();
		assertEquals("single", roomTypeValidation.roomTypeValidation(1));
	}

	@Test
	@DisplayName("number of rooms")
	void testNumberOfRooms() {
		InputValidation noOfRoomsValidation = Factory.getInputValidationInstance();
		assertEquals(true, noOfRoomsValidation.numberOfRoomsValidation("20"));
	}

	@Test
	@DisplayName("booking name")
	void testBookingName() {
		InputValidation bookingNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingNameValidation.bookingNameValidation("rama"));
	}

	@Test
	@DisplayName("update customer details")
	void testUpdateCustomerDetails() {
		InputValidation customerdetailsValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerdetailsValidation.choiceValidateOperateHotelDetails("3"));

	}

	@Test
	@DisplayName("room price")
	void testRoomPrice() {
		InputValidation priceValidation = Factory.getInputValidationInstance();
		assertEquals(true, priceValidation.priceValidation("650.00"));
	}
	

}
