package com.capgemini.hotelmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.LoginTest;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.Service;

public class LoginTest {
	static final Logger log = Logger.getLogger(LoginTest.class);
	Scanner scanner = new Scanner(System.in);

	@Test
	@DisplayName("Admin Login")
	void testadminLoginTest() {

		log.info("Test Case for Admin Login");
		Service adminLogin = Factory.getServiceInstance();
		assertEquals(false, adminLogin.getAdminLogin("admin", "admin"));
	}

	@Test
	@DisplayName("Admin Login")
	void testadminLoginTest1() {

		log.info("Test Case for Admin Login");
		Service adminLogin = Factory.getServiceInstance();
		assertEquals(false, adminLogin.getAdminLogin("admin12", "Admin@123"));
	}

	@Test
	@DisplayName("Employee Login")
	void testemployeeLoginTest() {
		log.info("Test Case for employee Login");
		Service employeeLogin = Factory.getServiceInstance();
		assertEquals(true, employeeLogin.getHotelManagementLogin("smiley111", "Smiley@111"));
	}

	@Test
	@DisplayName("Employee Login")
	void testemployeeLoginTest1() {
		log.info("Test Case for employee Login");
		Service employeeLogin = Factory.getServiceInstance();
		assertEquals(false, employeeLogin.getHotelManagementLogin("smiley", "Smiley@1203"));

	}

	@Test
	@DisplayName("Customer Login")
	void testcustomerLoginTest() {

		log.info("Test Case for Customer Login");
		Service customerLogin = Factory.getServiceInstance();
		assertEquals(true, customerLogin.getLoginCustomer("ramanath23", "Ramanath#23"));

	}

	@Test
	@DisplayName("Customer Login")
	void testcustomerLoginTest2() {

		log.info("Test Case for Customer Login");
		Service customerLogin = Factory.getServiceInstance();
		assertEquals(false, customerLogin.getLoginCustomer("rama", "rama@31"));

	}

}
