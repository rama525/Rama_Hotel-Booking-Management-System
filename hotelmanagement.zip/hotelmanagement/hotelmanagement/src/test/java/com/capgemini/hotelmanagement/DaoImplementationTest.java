package com.capgemini.hotelmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.bean.Room;
import com.capgemini.hotelmanagement.dao.Dao;
import com.capgemini.hotelmanagement.dao.DaoImpl;
import com.capgemini.hotelmanagement.factory.Factory;

public class DaoImplementationTest {
	Room room = Factory.getRoomInstance();
	Hotel hotel = Factory.getHotelInstance();
	CustomerRegistration customerRegistration = Factory.getCustomerRegistrationInstance();
	Booking bookingsBean = Factory.getBookingInstance();
	Dao dao = new DaoImpl();

	@Test
	@DisplayName("valid registration")
	void testAddCustomer() {
		assertEquals(true, dao.addCustomer(customerRegistration));
	}

	@Test
	@DisplayName("set booking")
	void testSetbooking() {
		assertNotNull(bookingsBean);
	}

	@Test
	@DisplayName("hotels list")
	void testGetHotels() {
		assertNotNull(hotel);
	}

	@Test
	@DisplayName("customerslist")
	void testGetCustomersList() {
		assertNotNull(customerRegistration);
	}

	@Test
	@DisplayName("booking list specific hotel")
	void testGetBookingsListSpecificHotel() {
		assertNotNull(customerRegistration);
	}

	@Test
	@DisplayName("booking list")
	void testGetBookingsList() {
		assertNotNull(customerRegistration);
	}

	@Test
	@DisplayName("valid add hotel")
	void testGetAddHotel() {
		assertEquals(true, dao.addHotel(hotel));
	}

	@Test
	@DisplayName("valid delete hotel")
	void testGetDeleteHotel() {
		assertEquals(true, dao.deleteHotel("Taj Hotel"));
	}

	@Test
	@DisplayName(" add room")
	void testGetAddRoom() {
		assertNotNull(room);
	}

	@Test
	@DisplayName("valid delete room ")
	void testGetDeleteRoom() {
		assertEquals(true, dao.deleteRoom("101"));
	}

	@Test
	@DisplayName("invalid delete room ")
	void testGetDeleteRoom1() {
		assertEquals(true, dao.deleteRoom("204"));
	}
}
